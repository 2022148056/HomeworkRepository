const express = require("express");
const app = express();
const sqlite3 = require("sqlite3").verbose();
const bodyParser = require("body-parser");
const fs = require("fs");

app.use(express.static("public"));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.set("view engine", "ejs");
const filePath = "comments.json";
let reviews = [];

fs.readFile(filePath, "utf8", (err, data) => {
  if (err) {
    console.error(err);
  } else {
    reviews = JSON.parse(data);
  }
});

const data = fs.readFileSync("product.json");
const products = JSON.parse(data);

const db = new sqlite3.Database("product.db");

app.get("/", function (req, res) {
  const { category, shoes_name, sort_type } = req.query;

  let sql = "SELECT * FROM products WHERE 1=1";

  const params = [];

  if (category && category !== "ALL") {
    sql += " AND category = ?";
    params.push(category);
  }

  if (shoes_name) {
    const searchTerm = `%${shoes_name}%`;
    sql += " AND title LIKE ?";
    params.push(searchTerm);
  }

  if (sort_type === "decreasing") {
    sql += " ORDER BY price DESC";
  } else if (sort_type === "increasing") {
    sql += " ORDER BY price ASC";
  }

  db.all(sql, [], (err, products) => {
    if (err) {
      console.error(err.message);
      res.status(500).json({ error: "An error occurred while searching." });
    } else {
      res.render("index", {
        products: products,
      });
    }
  });
});

app.get("/login", (req, res) => {
  res.render("login");
});

app.get("/signup", (req, res) => {
  res.render("signup");
});

app.get("/product", (req, res) => {
  res.render("product", {
    products: products,
  });
});

app.get("/product/:id", (req, res) => {
  const { id } = req.params;

  let sql = `SELECT * FROM products WHERE product_id = '${id}'`;

  db.all(sql, [], (err, products) => {
    if (err) {
      console.error(err.message);
      res.status(500).json({ error: "An error occurred while searching." });
    } else {
      res.render("product", {
        product: products[0],
        reviews: reviews.filter((review) => review.id === id),
      });
    }
  });
});

app.post("/product/:id", (req, res) => {
  const { id } = req.params;
  const { review_box } = req.body;

  if (review_box) {
    var obj = new Object();
    obj.id = id;
    obj.text = review_box;
    reviews.push(obj);

    fs.writeFile("comments.json", JSON.stringify(reviews), "utf8", (err) => {
      if (err) {
        console.error(err);
        return;
      }
    });
  }

  let sql = `SELECT * FROM products WHERE product_id = '${id}'`;

  db.all(sql, [], (err, products) => {
    if (err) {
      console.error(err.message);
      res.status(500).json({ error: "An error occurred while searching." });
    } else {
      res.render("product", {
        product: products[0],
        reviews: reviews.filter((review) => review.id === id),
      });
    }
  });
});

const port = process.env.PORT || 3000;

app.listen(port, () => {
  console.log(`Server started at http://localhost:${port}`);
});
